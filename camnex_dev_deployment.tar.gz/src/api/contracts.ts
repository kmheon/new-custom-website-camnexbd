import {
  Product,
  Category,
  Brand,
  SpecTemplate,
  SecurityPackage,
  CartItem,
  Order,
  Customer,
  QuoteRequest,
  SiteSettings,
  HomepageSection,
  BlogPost,
  ProjectCaseStudy,
  Testimonial,
  FaqItem,
  ProductResearchResult,
  DeliveryMethod,
  PaymentMethod,
  InstallationOption,
  HeroSlide,
  PackageSeries,
  PackageSystemType,
  ServiceOffering,
  CategoryFacetsResponse,
  SpecFacetGroup
} from '../types';

export interface ProductFilterParams {
  categorySlug?: string;
  category?: string;
  brandSlug?: string;
  brands?: string[];
  subcategory?: string;
  subcat?: string;
  minPrice?: number;
  maxPrice?: number;
  search?: string;
  specFilters?: Record<string, string | string[] | number | boolean>;
  sortBy?: 'price_asc' | 'price_desc' | 'name_asc' | 'popular' | 'newest' | 'created_at';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  totalPages: number;
}

// ----------------------------------------------------------------------------
// Core Domain Service Interfaces
// ----------------------------------------------------------------------------

export interface IProductService {
  getProducts(params?: ProductFilterParams): Promise<PaginatedResult<Product>>;
  getProductById(id: string): Promise<Product | null>;
  getProductBySku(sku: string): Promise<Product | null>;
  getFeaturedProducts(limit?: number): Promise<Product[]>;
  getPopularProducts(limit?: number): Promise<Product[]>;
  getRelatedProducts(productId: string, limit?: number): Promise<Product[]>;
  getCompatibleAccessories(productId: string): Promise<Product[]>;
  createProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product>;
  updateProduct(id: string, updates: Partial<Product>): Promise<Product>;
  deleteProduct(id: string): Promise<boolean>;
  archiveProduct?(id: string): Promise<any>;
  restoreProduct?(id: string): Promise<any>;
  bulkAdjustPrices?(payload: import('../types').BulkPriceAdjustmentPayload): Promise<import('../types').BulkOperationResult>;
  bulkMoveCategory?(payload: import('../types').BulkCategoryMovePayload): Promise<import('../types').BulkOperationResult>;
  bulkUpdateVisibility?(payload: import('../types').BulkVisibilityPayload): Promise<import('../types').BulkOperationResult>;
  bulkUpdateTags?(payload: import('../types').BulkTagPayload): Promise<import('../types').BulkOperationResult>;
  bulkDeleteProducts?(productIds: string[]): Promise<import('../types').BulkOperationResult>;
  bulkArchiveProducts?(productIds: string[], reason?: string): Promise<import('../types').BulkOperationResult>;
  getAvailableSpecFiltersForCategory(categorySlug: string): Promise<Record<string, string[]>>;
  getCategoryFacets?(categorySlug: string, subcategory?: string): Promise<CategoryFacetsResponse>;
}

export interface ICategoryService {
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | null>;
  createCategory(category: Omit<Category, 'id'>): Promise<Category>;
  updateCategory(id: string, updates: Partial<Category>): Promise<Category>;
  deleteCategory(id: string): Promise<boolean>;
}

export interface IBrandService {
  getBrands(): Promise<Brand[]>;
  getBrandBySlug(slug: string): Promise<Brand | null>;
  createBrand(brand: Omit<Brand, 'id'>): Promise<Brand>;
  updateBrand(id: string, updates: Partial<Brand>): Promise<Brand>;
  deleteBrand(id: string): Promise<boolean>;
}

export interface ISpecTemplateService {
  getTemplates(): Promise<SpecTemplate[]>;
  getTemplateById(id: string): Promise<SpecTemplate | null>;
  getTemplateByCategorySlug(categorySlug: string): Promise<SpecTemplate | null>;
  saveTemplate(template: SpecTemplate): Promise<SpecTemplate>;
  deleteTemplate(id: string): Promise<boolean>;
}

export interface IPackageService {
  getPackages(): Promise<SecurityPackage[]>;
  getPackageBySlug(slug: string): Promise<SecurityPackage | null>;
  calculatePackagePrice(config: {
    packageId: string;
    cameraCount: number;
    formFactor: string;
  }): Promise<{
    totalPrice: number | null;
    quotationRequired?: boolean;
    quotationReason?: string | null;
    components: Array<{
      role?: string;
      name: string;
      model: string;
      sku?: string;
      qty: number;
      unitPrice?: number | null;
      lineTotal?: number | null;
    }>;
  }>;
  savePackage(pkg: SecurityPackage): Promise<SecurityPackage>;
  getPackageSeries(): Promise<PackageSeries[]>;
  getAllPackageSeries(): Promise<PackageSeries[]>;
  savePackageSeries(series: PackageSeries): Promise<PackageSeries>;
  deletePackageSeries(id: string): Promise<void>;
  getPackageSystemTypes(): Promise<PackageSystemType[]>;
  getAllPackageSystemTypes(): Promise<PackageSystemType[]>;
  savePackageSystemType(st: PackageSystemType): Promise<PackageSystemType>;
  deletePackageSystemType(id: string): Promise<void>;
}

export interface ICartService {
  getCart(): Promise<CartItem[]>;
  addItem(item: Omit<CartItem, 'id'>): Promise<CartItem[]>;
  updateQuantity(lineId: string, quantity: number): Promise<CartItem[]>;
  removeItem(lineId: string): Promise<CartItem[]>;
  clearCart(): Promise<void>;
  calculateSummary(items: CartItem[], deliveryMethod: DeliveryMethod, installation: InstallationOption): Promise<{
    subtotal: number;
    deliveryFee: number;
    installationFee: number;
    tax: number;
    total: number;
  }>;
}

export interface IOrderService {
  createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'timeline' | 'status'>): Promise<Order>;
  getOrderById(id: string): Promise<Order | null>;
  getOrderByNumber(orderNumber: string, phone?: string): Promise<Order | null>;
  getAllOrders(): Promise<Order[]>;
  updateOrderStatus(orderId: string, status: string, note?: string): Promise<Order>;
  updatePaymentStatus(orderId: string, paymentStatus: string): Promise<Order>;
}

export interface IQuoteService {
  createQuote(data: Omit<QuoteRequest, 'id' | 'quoteNumber' | 'createdAt' | 'status'>): Promise<QuoteRequest>;
  createServiceRequest(data: { customerName: string; phone: string; serviceType: string; serviceId?: string; area?: string; website?: string }): Promise<any>;
  getServiceOfferings(): Promise<ServiceOffering[]>;
  getAllServiceOfferings(): Promise<ServiceOffering[]>;
  saveServiceOffering(service: ServiceOffering): Promise<ServiceOffering>;
  deleteServiceOffering(id: string): Promise<void>;
  getQuotes(): Promise<QuoteRequest[]>;
  getQuoteById(id: string): Promise<QuoteRequest | null>;
  updateQuoteStatus(id: string, status: QuoteRequest['status']): Promise<QuoteRequest>;
}

export interface ICmsService {
  getSiteSettings(): Promise<SiteSettings>;
  updateSiteSettings(settings: Partial<SiteSettings>): Promise<SiteSettings>;
  getHomepageSections(): Promise<HomepageSection[]>;
  updateHomepageSections(sections: HomepageSection[]): Promise<HomepageSection[]>;
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | null>;
  saveBlogPost(post: BlogPost): Promise<BlogPost>;
  deleteBlogPost(id: string): Promise<boolean>;
  getProjects(): Promise<ProjectCaseStudy[]>;
  getTestimonials(): Promise<Testimonial[]>;
  getFaqs(): Promise<FaqItem[]>;
  saveFaq(faq: FaqItem): Promise<FaqItem>;
  deleteFaq(id: string): Promise<boolean>;
  getHeroSlides(): Promise<HeroSlide[]>;
  saveHeroSlide(slide: HeroSlide): Promise<HeroSlide>;
  deleteHeroSlide(id: string): Promise<void>;
  resolveDisplaySlides(): Promise<HeroSlide[]>;
  clearDemoData(confirmPhrase?: string): Promise<void>;
  resetToInitialSeeds(confirmPhrase?: string): Promise<void>;
}

export interface IProductResearchService {
  startResearch(brand: string, modelNumber: string): Promise<ProductResearchResult>;
}
