import React from 'react';
import { createRoot } from 'react-dom/client';
import { StaffApp } from './StaffApp';

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(
    <React.StrictMode>
      <StaffApp />
    </React.StrictMode>
  );
}

