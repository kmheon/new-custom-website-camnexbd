// ============================================================================
// CamneX Bangladesh — Enterprise E-Commerce & Business Platform Domain Models
// Phase 1: Storefront, Catalog, Cart/Checkout, Quotes, Services, and Admin
// Designed for seamless Phase 2 POS / ERP integration
// ============================================================================

export type Role = 'admin' | 'super-admin' | 'staff' | 'editor' | 'support' | string;

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  permissions?: string[];
  status?: string;
  mustChangePassword?: boolean;
  token?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  companyName?: string;
  customerType: 'individual' | 'business';
  addresses: Address[];
  internalStaffNotes?: string;
  isArchived?: boolean;
  email_verified?: boolean;
  phone_verified?: boolean;
  emailVerified?: boolean;
  phoneVerified?: boolean;
  createdAt: string;
}

export interface Address {
  id: string;
  label: string; // e.g. "Office", "Home", "Warehouse"
  recipientName?: string;
  recipientPhone?: string;
  addressLine: string;
  area?: string;
  city?: string;
  district?: string;
  thana?: string;
  postalCode?: string;
  isDefault?: boolean;
}

// ----------------------------------------------------------------------------
// Specification Templates (Category-Owned)
// ----------------------------------------------------------------------------
export type SpecFieldType = 'text' | 'number' | 'boolean' | 'enum' | 'unit';

export interface SpecFieldDefinition {
  id: string;
  name: string; // e.g. "Resolution", "Night Vision Range"
  label?: string;
  key: string;  // e.g. "resolution", "night_vision_range"
  type: SpecFieldType;
  unit?: string; // e.g. "MP", "Meters", "Gbps", "Ports"
  options?: string[]; // for enum: e.g. ["2MP (1080p)", "4MP (2K)", "8MP (4K)"]
  required?: boolean;
  filterable?: boolean; // can be used in category faceted search
  comparable?: boolean; // shown in product comparison matrix
  showInHighlights?: boolean; // shown in hero banner highlights
  shortLabel?: string; // Max 14 characters compact label for tiles
  order: number;
}

export interface SpecTemplate {
  id: string;
  name: string; // e.g. "CCTV Camera", "NVR/DVR", "Network Switch", "Access Point", "Biometric Access Control", "Generic"
  categorySlug: string;
  fields: SpecFieldDefinition[];
}

export interface SpecFacetOption {
  value: string;
  label: string;
  count: number;
}

export interface SpecFacetGroup {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'boolean' | 'enum' | 'unit' | string;
  unit?: string;
  options: SpecFacetOption[];
}

export interface CategoryFacetsResponse {
  category: string;
  categoryName?: string;
  totalProducts: number;
  facets: SpecFacetGroup[];
  rawFilters?: Record<string, string[]>;
}

export type ProductSpecValues = Record<string, any>;

// ----------------------------------------------------------------------------
// Product & Catalog Models
// ----------------------------------------------------------------------------
export interface Brand {
  id: string;
  name: string; // Hikvision, ZKTeco, Dahua, Ruijie, TP-Link, Western Digital
  slug: string;
  logo?: string;
  description?: string;
  website?: string;
  featured?: boolean;
  badgeText?: string;
  showBadge?: boolean;
  showInBrandStrip?: boolean;
  order?: number;
  productCount?: number;
  seo?: ProductSeo;
}

export interface ScenarioItem {
  id: string;
  slug: string;
  title: string;
  description: string;
  iconName: string; // 'Home' | 'Building2' | 'ShoppingBag' | 'Factory' | 'GraduationCap'
  recommendedCategories?: string[];
  recommendedPackages?: string[];
  recommendedProducts?: string[];
  highlights?: string[];
  requirements?: string[];
  engineeringStandards?: string[];
  scale?: string;
  cablingStandard?: string;
  networkType?: string;
  enabled: boolean;
  order: number;
}

export interface PromoTileConfig {
  enabled?: boolean;
  headline: string;
  subtext?: string;
  buttonText: string;
  link: string;
  bgStyle?: 'orange' | 'dark' | 'tint'; // Orange, Dark, Soft tint
  image?: string;
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  order?: number;
  enabled?: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  image?: string;
  promoTile?: PromoTileConfig;
  parentId?: string | null;
  specTemplateId: string;
  featured?: boolean;
  showOnHomepage?: boolean;
  showAsHomepageRow?: boolean;
  isAccessoryCategory?: boolean;
  order: number;
  displayOrder?: number;
  status?: 'active' | 'inactive' | string;
  subcategories?: Subcategory[];
  seo?: ProductSeo;
  filterFieldKeys?: string[];
}

export interface ProductPrice {
  regularPrice?: number | null;   // In BDT (৳) - if undefined, "Request quotation"
  salePrice?: number | null;      // Optional promotional price
  wholesalePrice?: number | null; // Phase 2 B2B
  costPrice?: number | null;      // Guarded by pricing.cost.read
  saleStartDate?: string;         // ISO date YYYY-MM-DD
  saleEndDate?: string;           // ISO date YYYY-MM-DD
  currency?: 'BDT' | string;
}

export interface ProductInventory {
  available: number;
  reserved?: number;
  status?: 'in_stock' | 'low_stock' | 'out_of_stock' | 'pre_order' | 'request_quote';
  warehouseId?: string;
  trackQuantity?: boolean;
  lowStockThreshold?: number;
  allowBackorder?: boolean;
}

export interface ProductGalleryItem {
  url: string;
  altText?: string;
  caption?: string;
}

export interface ProductDocument {
  id: string;
  title: string;
  type: 'datasheet' | 'user_manual' | 'firmware' | 'quick_start_guide' | 'warranty_card';
  url: string;
  size?: string;
}

export interface ProductSeo {
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  canonicalUrl?: string;
  noIndex?: boolean;
}

export interface Product {
  id: string;
  name: string;
  shortName?: string; // Optional short display name for compact lists (max 36 chars); falls back to a stripped name
  brand: string;
  brandId: string;
  modelNumber: string;
  model?: string;
  sku: string;
  barcode?: string;
  barcodeFormat?: 'EAN-13' | 'UPC-A' | 'Code 128' | 'QR Code' | string;
  category: string;
  categoryId: string;
  categorySlug?: string;
  subcategory?: string;
  subcategoryId?: string;
  subcategorySlug?: string;
  productType: 'physical' | 'service' | 'package_bundle';
  status: 'active' | 'draft' | 'archived';
  archiveReason?: string;
  websiteVisible: boolean;
  posAvailable: boolean;
  slug?: string;
  images: string[];
  gallery?: string[];
  galleryItems?: ProductGalleryItem[];
  primaryImage: string;
  shortDescription: string;
  description: string;
  keyFeatures: string[];
  specifications: ProductSpecValues;
  specs?: Record<string, any>;
  pricing: ProductPrice;
  inventory: ProductInventory;
  costPrice?: number | null;
  wholesalePrice?: number | null;
  unit: string; // "Piece", "Meter", "Box", "Set"
  warrantyMonths?: number;
  warrantyType?: 'official' | 'vendor' | 'replacement' | string;
  warrantyText?: string;
  warranty?: string;
  documents?: ProductDocument[];
  compatibleProductIds?: string[];
  relatedProductIds?: string[];
  packageEligible?: boolean;
  packageRoles?: Array<'camera' | 'recorder' | 'storage' | 'cable' | 'power' | 'connectors' | 'accessory'>;
  serialTracking?: boolean;
  batchTracking?: boolean;
  seo?: ProductSeo;
  createdAt: string;
  updatedAt: string;
  isFeatured?: boolean;
  isPopular?: boolean;
  isDemo?: boolean; // Clearly labeled sample data
  sample?: boolean;
  isNew?: boolean;
  isNewArrival?: boolean;
  isHot?: boolean;
  isAccessory?: boolean;
  showOnHomepage?: boolean;
}

export interface ProductVariantOption {
  productId: string;
  modelNumber: string;
  name: string;
  distinguishingSpec: string;
  price?: number | null;
  regularPrice?: number | null;
  salePrice?: number | null;
  inStock?: boolean;
  primaryImage?: string;
}

export interface ProductVariantGroup {
  id: string;
  seriesName: string;
  distinguishingFeatureLabel?: string;
  productIds: string[];
  variants: ProductVariantOption[];
}

// ----------------------------------------------------------------------------
// Packages (Configurable Turnkey Bundles)
// ----------------------------------------------------------------------------
export type CameraFormFactor = 'bullet' | 'dome' | 'turret' | 'ptz' | 'other';

export type CameraSeriesId = 'analogue' | 'ip' | 'wireless';

export type CameraCategoryId =
  // Analogue / HD Series
  | 'analogue_bullet'
  | 'analogue_dome'
  | 'analogue_turret'
  | 'analogue_box'
  | 'analogue_ptz'
  // IP Series
  | 'ip_poe'
  | 'ip_smart_ai'
  | 'ip_multi_sensor'
  | 'ip_fisheye'
  | 'ip_specialized'
  // Wireless Series
  | 'wifi_smart'
  | 'wifi_cellular'
  | 'wifi_solar'
  | 'wifi_battery'
  | 'wifi_pinhole'
  | 'wifi_two_way_audio';

export type SpecialistSubcategory = 'anpr' | 'thermal' | 'industrial' | null;

export type StorageOption = '500gb' | '1tb' | '2tb' | '4tb' | 'dual_2tb' | 'dual_4tb' | 'quad_4tb' | 'none';

export type MonitorOption = 'none' | '17inch' | '19inch' | 'large';

export interface PowerSupplyProfile {
  name: string;
  model: string;
  sku: string;
  qty: number;
  unitPrice: number | null;
  lineTotal: number | null;
  warrantyMonths: number;
  type: 'adapter' | 'central_box' | 'integrated_poe' | 'external_poe_switch' | 'solar_autonomous' | 'rechargeable_battery';
  note?: string;
  badge?: string;
  description?: string;
  voltage?: string;
  currentRating?: string;
  fuseProtection?: string;
  ports?: number;
  poeBudgetW?: number;
  formFactor?: string;
}

export interface BomItem {
  role: string;
  name: string;
  model: string;
  sku: string;
  qty: number;
  unitPrice: number | null;
  lineTotal: number | null;
  specs?: string;
  warrantyMonths?: number;
  warrantyText?: string;
}

export interface PackageComponentRule {
  role: 'camera' | 'recorder' | 'storage' | 'cable' | 'power' | 'connectors' | 'installation';
  defaultModelId: string;
  name: string;
  shortName?: string;
  quantityFormula: 'fixed' | 'per_camera' | 'lookup_camera_count';
  fixedQty?: number;
  qtyPerCamera?: number;
  storageLookup?: Record<number, { capacity: string; modelId: string }>; // e.g. {2: 500GB, 4: 500GB, 8: 1TB, 16: 2TB}
}

export interface PackageSeries {
  id: string;
  name: string;
  slug: string;
  description: string;
  order: number;
  enabled: boolean;
  illustration?: string;
  ruleSet?: {
    hasStorageRule?: boolean;
    storageMap?: Record<number, string>;
    hasCableRule?: boolean;
    cableMetersPerCam?: number;
    hasRecorderRule?: boolean;
    recorderChannels?: number;
    allowPtz?: boolean;
    allowPoESwitch?: boolean;
  };
}

export interface PackageSystemType {
  id: string;
  name: string;
  slug: string; // 'ip', 'analogue', 'wireless'
  shortLabel?: string; // 'IP', 'Analogue', 'Wi-Fi'
  description: string;
  icon?: string;
  order: number;
  enabled: boolean;
  ruleSet?: {
    recorderType?: 'dvr' | 'nvr' | 'none' | 'wireless_nvr';
    cableType?: 'coaxial_dc' | 'cat6_utp' | 'none';
    cableMetersPerCam?: number;
    powerSupplyType?: 'centralized_12v' | 'poe_switch' | 'individual_adapters';
    storageType?: 'surveillance_hdd' | 'microsd_or_nvr_hdd';
    storageMap?: Record<number, string>;
    hasBaluns?: boolean;
    descriptionSummary?: string;
  };
}

export interface SecurityPackage {
  id: string;
  name: string;
  slug: string;
  badge?: string; // "Most Popular", "Best for Small Homes"
  featuredOnHomepage?: boolean; // Admin priority flag for homepage mix
  description: string;
  image?: string;
  systemTypeId?: string;
  systemType?: string;
  systemTypeSlug?: string; // 'ip' | 'analogue' | 'wireless'
  systemTypeName?: string;
  order?: number;
  seriesId?: string; // Night view series id (e.g. 'series-ir', 'series-hybrid', 'series-color', 'series-enterprise')
  seriesName?: string;
  nightViewId?: string;
  nightViewName?: string;
  technologyLabel?: string;
  cameraResolution?: string;
  cameraModel?: string;
  dvrModel?: string;
  storageDescription?: string;
  inclusions?: string[];
  cameraCountsSupported?: number[]; // [2, 4, 8, 16, 32, 64]
  defaultCameraCount?: number;
  cameraCount?: number;
  supportedFormFactors?: CameraFormFactor[];
  isNightVisionIrOnly?: boolean; // Uses IRPF series, no fake color/audio
  isQuoteOnly?: boolean;
  componentQuantities?: Record<string, number>;
  components?: Array<{
    name: string;
    sku?: string;
    qty: number;
    unitPrice?: number | null;
    lineTotal?: number | null;
  }>;
  quotationRequired?: boolean;
  rules?: PackageComponentRule[];
  pricingRules?: Record<string, any>;
  basePrice?: number | null;
  isActive?: boolean;
  isFeatured?: boolean;
  isDemo?: boolean;
}

// ----------------------------------------------------------------------------
// Cart, Checkout & Orders
// ----------------------------------------------------------------------------
export interface CartItem {
  id: string; // unique cart line id
  productId: string;
  product: Product;
  quantity: number;
  selectedFormFactor?: CameraFormFactor;
  pricePerUnit: number;
  packageConfig?: {
    packageId: string;
    packageName: string;
    cameraCount: number;
    storageSize: string;
    formFactor: CameraFormFactor;
  };
}

export type DeliveryMethod = 'inside_dhaka' | 'outside_dhaka' | 'store_pickup';
export type PaymentMethod = 'cod' | 'bkash_manual' | 'nagad_manual' | 'bank_transfer' | 'online_gateway';

export interface PaymentDetails {
  method: PaymentMethod;
  senderNumber?: string;
  transactionId?: string;
  bankName?: string;
  depositRef?: string;
  gatewayRef?: string;
  paidAt?: string;
}

export interface InstallationOption {
  requested: boolean;
  preferredDate?: string;
  preferredTimeSlot?: 'morning' | 'afternoon' | 'evening';
  siteNotes?: string;
  estimatedFee: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'dispatched' | 'delivered' | 'cancelled';

export interface OrderTimelineEvent {
  status: OrderStatus | string;
  title: string;
  note?: string;
  timestamp: string;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. "CNX-ORD-202610-1042"
  customerId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  deliveryAddress: string;
  deliveryCity: string;
  deliveryMethod: DeliveryMethod;
  deliveryFee: number;
  installation: InstallationOption;
  paymentMethod: PaymentMethod;
  paymentStatus: 'unpaid' | 'unverified' | 'paid';
  paymentDetails?: PaymentDetails;
  items: Array<{
    productId: string;
    name: string;
    model: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
    image: string;
    packageDetails?: string;
  }>;
  subtotal: number;
  tax: number;
  total: number;
  status: OrderStatus;
  timeline: OrderTimelineEvent[];
  notes?: string;
  internalStaffNotes?: string;
  courierName?: string;
  trackingNumber?: string;
  shipmentStatus?: string;
  courierTrackingUrl?: string | null;
  estimatedDeliveryDate?: string | null;
  deliveryInfo?: {
    method?: string;
    district?: string;
    estimatedTime?: string | null;
  };
  itemCount?: number;
  contactSupport?: {
    phone?: string;
    email?: string;
    whatsapp?: string;
  };
  createdAt: string;
  isDemo?: boolean;
  captchaToken?: string;
}

// ----------------------------------------------------------------------------
// Inquiries, Quotes & Site Surveys
// ----------------------------------------------------------------------------
export type ServiceType =
  | 'cctv_installation'
  | 'site_survey'
  | 'networking_wifi'
  | 'access_control_biometric'
  | 'it_infrastructure'
  | 'maintenance_amc'
  | 'home_automation'
  | 'fire_safety'
  | 'configuration'
  | 'other';

export interface QuoteRequest {
  id: string;
  quoteNumber: string;
  customerName: string;
  companyName?: string;
  phone: string;
  email?: string;
  serviceType: ServiceType;
  propertyType: 'home' | 'office' | 'shop' | 'warehouse' | 'factory' | 'other';
  siteAddress: string;
  cameraCount?: number;
  doorCount?: number;
  preferredDate?: string;
  notes: string;
  internalStaffNotes?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  quotationAmount?: number;
  status: 'pending' | 'contacted' | 'quoted' | 'approved' | 'rejected';
  estimatedBudget?: string;
  attachmentName?: string;
  createdAt: string;
  isDemo?: boolean;
}

// ----------------------------------------------------------------------------
// Site Settings, CMS & Content
// ----------------------------------------------------------------------------
export interface CtaReassuranceItem {
  id: string;
  label: string;
  enabled: boolean;
}

export interface CtaActionCard {
  id: string;
  title: string;
  description: string;
  type: 'whatsapp' | 'call' | 'survey' | 'custom';
  actionUrl?: string;
  phoneDisplay?: string;
  buttonText?: string;
}

export interface CtaSectionData {
  eyebrow: string;
  heading: string;
  subtext: string;
  cards: CtaActionCard[];
  reassurances: CtaReassuranceItem[];
}

export interface FooterLinkItem {
  label: string;
  route: string;
  param?: string;
  external?: string;
}

export interface FooterNavigationSettings {
  description?: string;
  quickLinks: FooterLinkItem[];
  products: FooterLinkItem[];
  customerSupport: FooterLinkItem[];
  newsletterText?: string;
  copyrightText?: string;
  developerCredit?: string;
}

export interface SiteSettings {
  companyName: string;
  phone: string;
  email: string;
  secondaryEmail: string;
  website: string;
  facebookUrl: string;
  youtubeUrl?: string;
  linkedinUrl?: string;
  whatsappNumber?: string;
  address: string;
  credentials: string[]; // ["Hikvision Authorized Partner", "ZKTeco Authorized Installer"]
  services: string[];
  businessHours: string;
  enableStockBadges: boolean;
  sampleDataBanner: boolean;
  showSampleContent?: boolean;
  showDemoTags?: boolean; // Toggle "Show demo tags" on sample cards (default true)
  allSystemTypeDescription?: string;
  announcementBar?: {
    enabled: boolean;
    text: string;
    link?: string;
    dismissible?: boolean;
  };
  topBarHighlights?: Array<{
    id: string;
    text: string;
    icon?: string;
    link?: string;
    highlighted?: boolean;
    enabled: boolean;
    order: number;
  }>;
  quickServiceSettings?: {
    heading?: string;
    subtext?: string;
    buttonText?: string;
    nameLabel?: string;
    namePlaceholder?: string;
    phoneLabel?: string;
    phonePlaceholder?: string;
    areaLabel?: string;
    areaPlaceholder?: string;
    successMessage?: string;
    enableOtherOption?: boolean;
  };
  promoBanner?: {
    enabled: boolean;
    text: string;
    link?: string;
  };
  specialOfferSlider?: {
    enabled?: boolean;
    interval?: number;
    maxOffers?: number;
  };
  footer?: FooterNavigationSettings;
  servicesList?: ServiceItem[];
  processSteps?: ProcessStep[];
  servicesSectionPhoto?: string;
  solutions?: ScenarioItem[];
  scenarios?: ScenarioItem[];
  reassurances?: string[];
  accessoriesSubtitle?: string;

  // Global SEO Configuration
  seoTitle?: string;
  seoDescription?: string;
  seoOgImage?: string;

  // Real Merchant & Financial Settings (Empty by default until entered by admin)
  bkashMerchantNumber?: string;
  nagadMerchantNumber?: string;
  bankDetails?: {
    bankName?: string;
    accountName?: string;
    accountNumber?: string;
    branchName?: string;
    branch?: string;
    routingNumber?: string;
  } | null;
  deliveryFeeInsideDhaka?: number | null;
  deliveryFeeOutsideDhaka?: number | null;
  installationBaseFee?: number | null;
  enableCashOnDelivery?: boolean; // Admin setting: OFF by default in clean DB

  // Policy Text
  warrantyPolicyText?: string;
  returnPolicyText?: string;
  termsPolicyText?: string;
  privacyPolicyText?: string;

  // Delivery & Courier Configuration
  deliveryZones?: DeliveryZone[];
  courierIntegrations?: {
    steadfast?: CourierAdapterConfig;
    pathao?: CourierAdapterConfig;
  };

  // Installation Rates
  installationOptions?: InstallationRateSetting[];

  // Tax & Invoice Numbering
  taxRules?: TaxRuleConfig;

  // Localization
  localization?: LocalizationConfig;

  // Notification Templates
  notificationTemplates?: NotificationTemplate[];

  // Professional BOM & Quotation Letterhead Template
  letterheadTemplate?: LetterheadTemplateConfig;

  // Localization & Translation Readiness
  languageSwitcherEnabled?: boolean;
  defaultLanguage?: 'en' | 'bn';
  contentOverrides?: Record<string, string>;
}

export interface LetterheadTemplateConfig {
  id: string;
  name: string;
  isDefault: boolean;
  companyName: string;
  tagline: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  primaryColor: string;
  secondaryColor: string;
  validityDays: number;
  disclaimerText: string;
}


export interface DeliveryZone {
  id: string;
  name: string;
  code: string;
  standardFee: number;
  expressFee?: number;
  estimatedDelivery: string;
  freeDeliveryThreshold?: number;
  enabled: boolean;
}

export interface CourierAdapterConfig {
  provider: 'steadfast' | 'pathao';
  enabled: boolean;
  testMode?: boolean;
  apiKey?: string;
  secretKey?: string;
  clientId?: string;
  clientSecret?: string;
  username?: string;
  password?: string;
  storeId?: string;
  webhookSecret?: string;
}

export interface InstallationRateSetting {
  id: string;
  name: string;
  description: string;
  fee: number;
  unit: string;
  enabled: boolean;
}

export interface TaxRuleConfig {
  vatEnabled: boolean;
  defaultVatRate: number;
  pricesIncludeVat: boolean;
  binNumber?: string;
  tinNumber?: string;
  invoicePrefix: string;
  nextInvoiceNumber: number;
}

export interface LocalizationConfig {
  currencyCode: string;
  currencySymbol: string;
  timezone: string;
  businessHours: string;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  trigger: 'order_placed' | 'order_confirmed' | 'order_dispatched' | 'quote_received' | 'callback_requested';
  channel: 'email' | 'sms';
  subject?: string;
  body: string;
  enabled: boolean;
  variables: string[];
}

export interface Coupon {
  id: string;
  code: string;
  discount_type: 'percent' | 'fixed';
  discount_value: number;
  min_order_amount?: number;
  max_discount_amount?: number;
  scope_type?: 'all' | 'category' | 'product' | 'package';
  scope_id?: string;
  start_date?: string;
  end_date?: string;
  usage_limit?: number;
  usage_count: number;
  is_active: boolean | number;
  created_at: string;
  updated_at?: string;
}

export interface DocumentItem {
  id: string;
  title: string;
  doc_type: 'datasheet' | 'user_manual' | 'firmware' | 'catalog' | 'certificate';
  category_id?: string;
  product_id?: string;
  file_url: string;
  file_size?: string;
  mime_type?: string;
  download_count: number;
  created_at: string;
}


export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon?: string;
  link?: string;
  enabled: boolean;
  order: number;
}

export interface ServiceOffering {
  id: string;
  title: string;
  shortLabel: string;
  description?: string;
  icon?: string;
  enabled: boolean;
  order: number;
  solutionLink?: string;
}

export interface ProcessStep {
  id: string;
  stepNumber: number;
  title: string;
  description: string;
}

export interface HomepageSection {
  id: string;
  type: 'hero' | 'brands' | 'categories' | 'popular_products' | 'special_offers' | 'new_arrivals' | 'accessories' | 'services' | 'solutions' | 'packages' | 'trending' | 'category_row' | 'testimonials' | 'projects' | 'quote_cta' | 'credentials' | 'featured_products' | string;
  title: string;
  eyebrow?: string;
  subtitle?: string;
  enabled: boolean;
  order: number;
  categoryId?: string;
  categorySlug?: string;
  itemLimit?: number;
  showChipRow?: boolean;
  ctaData?: CtaSectionData;
  promoTile?: PromoTileConfig;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  author: string;
  publishedAt: string;
  excerpt: string;
  content: string; // sanitized HTML or markdown
  featuredImage: string;
  tags: string[];
  readTime: string;
  isDemo?: boolean;
  seoTitle?: string;
  seoDescription?: string;
  enableArticleSchema?: boolean;
}

export interface ProjectCaseStudy {
  id: string;
  title: string;
  category: 'Home' | 'Office' | 'Commercial' | string;
  location?: string;
  description?: string;
  systemSummary?: string;
  cameraCount?: string;
  clientQuote?: string;
  clientAuthor?: string;
  image?: string;
  isDemo?: boolean;
}

export interface Testimonial {
  id: string;
  name?: string;
  clientName?: string;
  client_name?: string;
  role?: string;
  clientRole?: string;
  company?: string;
  location?: string;
  comment?: string;
  content?: string;
  rating?: number;
  verified?: boolean;
  isDemo?: boolean;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

// ----------------------------------------------------------------------------
// Product Research Assistant (Mode A & Mode B)
// ----------------------------------------------------------------------------
export interface ResearchConfidenceField<T = any> {
  value: T;
  sourceUrl?: string;
  confidence: 'high' | 'medium' | 'low' | 'unverified';
  status: 'accepted' | 'edited' | 'rejected' | 'pending';
}

export interface ProductResearchResult {
  jobId: string;
  modelQuery: string;
  brand: string;
  suggestedName: ResearchConfidenceField<string>;
  suggestedCategory: ResearchConfidenceField<string>;
  suggestedShortDesc: ResearchConfidenceField<string>;
  suggestedKeyFeatures: ResearchConfidenceField<string[]>;
  suggestedSpecs: Record<string, ResearchConfidenceField<any>>;
  suggestedDocuments: ResearchConfidenceField<Array<{ title: string; url: string; type: string }>>;
  datasheetUrl?: string;
  sourcePriorityRanked: string[];
}

// ----------------------------------------------------------------------------
// Hero Slider & Banner Models (Phase 1 Light & Airy Master Slider)
// ----------------------------------------------------------------------------
export type HeroSlideBadge = 'New' | 'Featured' | 'Hot' | string;
export type HeroSlideSourceMode = 'manual' | 'product' | 'collection';
export type HeroCollectionRule = 'newest' | 'featured' | 'hot' | 'category';

export interface HeroFeatureHighlight {
  icon?: string; // e.g. "camera", "eye", "shield", "cpu", "wifi", "network", "zap"
  value: string; // e.g. "4K Ultra HD", "30m", "IP67", "PoE 54W"
  label: string; // e.g. "Resolution", "Smart IR", "Weatherproof", "Power Budget"
}

export interface HeroSlideOverrides {
  eyebrow?: string;
  headline?: string;
  modelNumber?: string;
  description?: string;
  badge?: HeroSlideBadge;
  showBadge?: boolean;
  tabLabel?: string;
  image?: string;
  priceText?: string;
  buttonText?: string;
  buttonLink?: string;
  secondaryText?: string;
  secondaryLink?: string;
  highlights?: HeroFeatureHighlight[];
}

export interface HeroSlide {
  id: string;
  title: string; // Admin internal reference name
  enabled: boolean;
  order: number;
  startDate?: string;
  endDate?: string;
  sourceMode: HeroSlideSourceMode;

  // Mode 1: Manual properties
  badge?: HeroSlideBadge;
  showBadge?: boolean;
  modelNumber?: string; // e.g. "DS-2CE10DF0T-F"
  eyebrow?: string; // e.g. "MEET THE NEW", "NEXT-GEN SURVEILLANCE"
  tabLabel?: string; // Max 22 chars tab label e.g. "ColorVu Camera"
  headline?: string;
  description?: string;
  image?: string; // Transparent PNG / WebP url
  priceText?: string; // Formatted price e.g. "৳2,450"
  buttonText?: string; // e.g. "View Product"
  buttonLink?: string; // e.g. "/product/prod-hik-irpf-2mp"
  secondaryButtonText?: string; // e.g. "Request quotation"
  secondaryButtonLink?: string;
  secondaryText?: string;
  secondaryLink?: string;
  highlights?: HeroFeatureHighlight[]; // Up to 4 feature highlights

  // Mode 2: From Product
  productId?: string;
  fieldOverrides?: Record<string, boolean>; // Per-field override switch in From-product mode
  overrideFlags?: {
    headline?: boolean;
    description?: boolean;
    badge?: boolean;
    image?: boolean;
    price?: boolean;
    highlights?: boolean;
    modelNumber?: boolean;
    eyebrow?: boolean;
    tabLabel?: boolean;
    buttons?: boolean;
  };
  overrides?: HeroSlideOverrides;

  // Mode 3: Auto Collection
  collectionRule?: HeroCollectionRule;
  collectionCategoryId?: string;
  categorySlug?: string;
  collectionCount?: number;
}

export interface MediaItem {
  id: string;
  filename: string;
  original_name?: string;
  url: string;
  mime_type?: string;
  size?: number;
  alt_text?: string;
  folder?: string;
  created_at?: string;
}

export interface PremiseEstimate {
  type: string;
  label: string;
  multiplier: number;
}

export interface QuoteFormData {
  propertyType: string;
  serviceNeeded: string;
  cameraCount: number;
  doorCount: number;
  storageDays: string;
  name: string;
  phone: string;
  location: string;
  preferredDate: string;
  notes: string;
  packagePreselected?: string;
}

export interface SearchResult {
  products: Array<{ id: number; name: string; model: string; price: number; image?: string; category_name?: string }>;
  categories: Array<{ id: number; name: string; slug: string; description: string }>;
  packages: Array<{ id: number; name: string; slug: string; camera_count: number; base_price: number; image?: string }>;
  services: Array<{ name: string; category: string; description: string; url: string }>;
}

// ----------------------------------------------------------------------------
// Bulk Operations & Catalog Import/Export
// ----------------------------------------------------------------------------
export type BulkPriceMode = 'percent_increase' | 'percent_decrease' | 'fixed_increase' | 'fixed_decrease' | 'set_fixed';

export interface BulkPriceAdjustmentPayload {
  productIds: string[];
  mode: BulkPriceMode;
  amount: number; // percentage (e.g. 10 for 10%) or fixed BDT (e.g. 500)
  targetField?: 'regularPrice' | 'salePrice' | 'wholesalePrice';
  roundToNearest?: number; // e.g. 50, 100 or 1
}

export interface BulkCategoryMovePayload {
  productIds: string[];
  categoryId: string;
  categoryName?: string;
  subcategoryId?: string;
  subcategoryName?: string;
}

export interface BulkVisibilityPayload {
  productIds: string[];
  websiteVisible?: boolean;
  posAvailable?: boolean;
  status?: 'active' | 'draft' | 'archived';
}

export interface BulkTagPayload {
  productIds: string[];
  tags: {
    isFeatured?: boolean;
    isPopular?: boolean;
    isNewArrival?: boolean;
    isHot?: boolean;
    isAccessory?: boolean;
  };
}

export interface BulkOperationResult {
  success: boolean;
  affectedCount: number;
  operationId: string;
  details?: Array<{ id: string; oldVal?: any; newVal?: any }>;
}

export interface CatalogImportRow {
  name: string;
  sku: string;
  brand: string;
  category: string;
  subcategory?: string;
  modelNumber?: string;
  regularPrice: number;
  salePrice?: number;
  costPrice?: number;
  availableStock?: number;
  shortDescription?: string;
  unit?: string;
  barcode?: string;
}

export interface CatalogImportPreview {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  errors: Array<{ row: number; error: string; field?: string }>;
  rows: CatalogImportRow[];
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  status: 'active' | 'unsubscribed';
  source?: string;
  createdAt: string;
  unsubscribedAt?: string;
}

export interface CallbackRequest {
  id: string;
  requestNumber: string;
  customerName: string;
  phone: string;
  serviceType: string;
  serviceId?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  internalNotes?: string;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  entity: string;
  entityId: string;
  action: string;
  actorId?: string;
  actorName?: string;
  actorEmail?: string;
  surface?: string;
  ip?: string;
  createdAt: string;
  before?: any;
  after?: any;
  diff?: any;
}

export interface BackgroundJobItem {
  id: string;
  type: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  payload?: any;
  result?: any;
  attempts: number;
  max_attempts: number;
  last_error?: string;
  run_at?: string;
  created_at: string;
  updated_at?: string;
  completed_at?: string;
}

export interface SystemHealthData {
  status: string;
  nodeVersion: string;
  platform: string;
  arch: string;
  uptimeSeconds: number;
  uptimeFormatted: string;
  memory: {
    rssBytes: number;
    rssFormatted: string;
    heapTotalBytes: number;
    heapTotalFormatted: string;
    heapUsedBytes: number;
    heapUsedFormatted: string;
  };
  database: {
    path: string;
    sizeBytes: number;
    sizeFormatted: string;
    journalMode: string;
    tableCounts: Record<string, number>;
  };
  workers: {
    backgroundQueue: string;
    domainEventsOutbox: string;
  };
}



